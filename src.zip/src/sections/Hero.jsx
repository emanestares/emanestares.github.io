import { PerspectiveCamera } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import Room from "../components/Room";
import Laptop from "../components/Laptop";
import Cellphone from "../components/Cellphone";
import Robot from "../components/Robot";
import Arduino from "../components/Arduino";
import CanvasLoader from "../components/CanvasLoader";
import { Suspense, useEffect, useState } from "react";
import { useMediaQuery } from "react-responsive";
import HeroCamera from "../components/HeroCamera";
import bgImage from '/assets/herobg-1.png';

const Hero = () => {
  const isMobile = useMediaQuery({ maxWidth: 768 });
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 150);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      className="min-h-screen w-full relative overflow-hidden"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/55 z-[1]" />

      {/* Giant background name — z-[2], behind 3D and text */}
      <div className="hero-bg-name" aria-hidden="true">ESTARES</div>

      {/* 3D Canvas — full viewport, all objects positioned in world space */}
      <div className="absolute inset-0 w-full h-full z-[3] pointer-events-none">
        <Canvas className="w-full h-full">
          <Suspense fallback={<CanvasLoader />}>
            <PerspectiveCamera makeDefault position={[0, 0, 30]} />
            <HeroCamera isMobile={isMobile}>

              {/* ── Room — centre-right hero ── */}
              <Room
                scale={isMobile ? 5.0 : 7.5}
                position={isMobile ? [0, -4.0, 0] : [2.5, -4.5, 0]}
                rotation={[0.1, -3.49, 0.01]}
              />

              {/* ── Laptop — lower-left, partially behind the "E" of ESTARES ── */}
              <Laptop
                scale={isMobile ? 0.07 : 0.11}
                position={isMobile ? [-7, -10, 0] : [-13, -9, 0]}
                rotation={[0.1, 0.6, 0.0]}
              />

              {/* ── Cellphone — lower-right, near the "S" ── */}
              <Cellphone
                scale={isMobile ? 0.09 : 0.14}
                position={isMobile ? [7, -10, 0] : [15, -9, 0]}
                rotation={[0.1, -0.6, 0.0]}
              />

              {/* ── Robot — upper-right, small accent ── */}
              <Robot
                scale={isMobile ? 0.9 : 1.6}
                position={isMobile ? [7.5, 8, 0] : [17, 9, 0]}
                rotation={[0.05, -1.2, 0.0]}
              />

              {/* ── Arduino — upper-left, small accent ── */}
              <Arduino
                scale={isMobile ? 1.5 : 3.5}
                position={isMobile ? [-7.5, 8, 0] : [-17, 9, 0]}
                rotation={[0.1, 0.8, 0.0]}
              />

            </HeroCamera>
            <ambientLight intensity={1.2} />
            <directionalLight position={[10, 10, 10]} intensity={0.6} />
          </Suspense>
        </Canvas>
      </div>

      {/* Top-left: tag + headline */}
      <div
        className={`hero-topleft z-[4] transition-all duration-700 ${
          visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
        }`}
      >
        <div className="hero-tag">Available for work</div>
        <h1 className="hero-title-new">
          Building tech<br />
          for <span className="hero-title-accent">real impact.</span>
        </h1>
      </div>

      {/* Bottom-right: subtitle + CTA */}
      <div
        className={`hero-bottomright z-[4] transition-all duration-700 delay-200 ${
          visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
        }`}
      >
        <p className="hero-desc-new">
          Full-stack developer with a focus on mobile, AI, and systems that matter —
          from disaster response tools to microbe classifiers.
        </p>
        <div className="hero-cta-row">
          <a href="#experience" className="hero-cta-pill">
            View My Work
            <span className="hero-cta-arrow">→</span>
          </a>
          <a href="#about" className="hero-cta-ghost">About Me</a>
        </div>
      </div>

      {/* Scroll hint */}
      <div className="hero-scroll-hint z-[4]">
        <span className="hero-scroll-line" />
        <span className="hero-scroll-label">scroll</span>
      </div>
    </section>
  );
};

export default Hero;
